/**
 * 
 */
package com.coolsql.plugin;

/**
 * @author ��Т��(kenny liu)
 *
 * 2008-1-12 create
 */
public class PluginSetting {

	private String file;
	public PluginSetting(String file)
	{
		this.file=file;
	}
	
}
