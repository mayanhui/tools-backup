/*
 * �������� 2006-7-7
 *
 */
package com.coolsql.action.common;

/**
 * @author liu_xlin
 *
 */
public interface Command {
   public abstract void execute();
}
